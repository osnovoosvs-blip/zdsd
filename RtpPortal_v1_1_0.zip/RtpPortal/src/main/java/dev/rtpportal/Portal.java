package dev.rtpportal;

import org.bukkit.Location;

/** Портал: кубоид блоков (границы включительно) в одном мире. */
public record Portal(String name, String world,
                     int minX, int minY, int minZ,
                     int maxX, int maxY, int maxZ) {

    public boolean containsBlock(String worldName, int x, int y, int z) {
        return world.equals(worldName)
                && x >= minX && x <= maxX
                && y >= minY && y <= maxY
                && z >= minZ && z <= maxZ;
    }

    /** Игрок в портале, если в нём ноги или голова. */
    public boolean contains(Location l) {
        if (l.getWorld() == null) return false;
        String w = l.getWorld().getName();
        int x = l.getBlockX();
        int y = l.getBlockY();
        int z = l.getBlockZ();
        return containsBlock(w, x, y, z) || containsBlock(w, x, y + 1, z);
    }
}
