package dev.rtpportal;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Player;

import java.time.Duration;
import java.util.Collection;
import java.util.concurrent.ThreadLocalRandom;

/** Анимация портала: спираль, светящаяся рамка, искры и звуки. */
final class PortalEffects {
    private final RtpPortalPlugin plugin;
    private long tick;

    private boolean enabled = true;
    private boolean frame = true;
    private boolean swirl = true;
    private boolean sparkles = true;
    private boolean sound = true;
    private Color from = Color.fromRGB(0x8A2BE2);
    private Color to = Color.fromRGB(0x00E5FF);
    private String title = "";
    private String subtitle = "";

    PortalEffects(RtpPortalPlugin plugin) {
        this.plugin = plugin;
    }

    void reload() {
        var c = plugin.getConfig();
        enabled = c.getBoolean("effects.enabled", true);
        frame = c.getBoolean("effects.frame", true);
        swirl = c.getBoolean("effects.swirl", true);
        sparkles = c.getBoolean("effects.sparkles", true);
        sound = c.getBoolean("effects.sound", true);
        from = parse(c.getString("effects.color-from", "#8A2BE2"), Color.fromRGB(0x8A2BE2));
        to = parse(c.getString("effects.color-to", "#00E5FF"), Color.fromRGB(0x00E5FF));
        title = c.getString("effects.enter-title", "&b&lПортал");
        subtitle = c.getString("effects.enter-subtitle", "&7Телепортация...");
    }

    private static Color parse(String s, Color def) {
        try {
            String h = s.startsWith("#") ? s.substring(1) : s;
            return Color.fromRGB(Integer.parseInt(h, 16));
        } catch (Exception e) {
            return def;
        }
    }

    /** Вызывается каждые 2 тика. */
    void run(Collection<Portal> portals) {
        if (!enabled) return;
        tick++;
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        for (Portal p : portals) {
            World w = Bukkit.getWorld(p.world());
            if (w == null) continue;

            double dx = p.maxX() - p.minX() + 1;
            double dy = p.maxY() - p.minY() + 1;
            double dz = p.maxZ() - p.minZ() + 1;
            double cx = p.minX() + dx / 2.0;
            double cy = p.minY() + dy / 2.0;
            double cz = p.minZ() + dz / 2.0;
            Location center = new Location(w, cx, cy, cz);

            boolean near = false;
            for (Player pl : w.getPlayers()) {
                if (pl.getLocation().distanceSquared(center) < 48 * 48) {
                    near = true;
                    break;
                }
            }
            if (!near) continue;

            boolean longX = dx >= dz;
            double halfA = (longX ? dx : dz) / 2.0;
            double halfY = dy / 2.0;
            double ca = longX ? cx : cz;

            if (swirl) {
                double base = tick * 0.12;
                for (int arm = 0; arm < 3; arm++) {
                    for (int j = 1; j <= 8; j++) {
                        double r = j / 8.0;
                        double ang = base + arm * (2 * Math.PI / 3) + r * 3.5;
                        double a = ca + Math.cos(ang) * r * halfA;
                        double y = cy + Math.sin(ang) * r * halfY;
                        dust(w, point(w, longX, cx, cz, a, y), 0.9f + (float) (1 - r) * 0.6f);
                    }
                }
                if (tick % 5 == 0) {
                    w.spawnParticle(Particle.END_ROD, center, 1, 0.1, 0.1, 0.1, 0.01);
                }
            }

            if (frame && tick % 2 == 0) {
                double minA = (longX ? p.minX() : p.minZ());
                double maxA = minA + (longX ? dx : dz);
                double minY = p.minY();
                double maxY = minY + dy;
                double perimeter = 2 * ((maxA - minA) + (maxY - minY));
                double step = Math.max(0.5, perimeter / 70.0);
                for (double a = minA; a <= maxA; a += step) {
                    dust(w, point(w, longX, cx, cz, a, minY), 1.1f);
                    dust(w, point(w, longX, cx, cz, a, maxY), 1.1f);
                }
                for (double y = minY; y <= maxY; y += step) {
                    dust(w, point(w, longX, cx, cz, minA, y), 1.1f);
                    dust(w, point(w, longX, cx, cz, maxA, y), 1.1f);
                }
            }

            if (sparkles) {
                for (int i = 0; i < 3; i++) {
                    Location loc = new Location(w,
                            p.minX() + rnd.nextDouble() * dx,
                            p.minY() + rnd.nextDouble() * dy,
                            p.minZ() + rnd.nextDouble() * dz);
                    w.spawnParticle(Particle.PORTAL, loc, 2, 0.2, 0.2, 0.2, 0.3);
                }
                if (tick % 6 == 0) {
                    Location loc = new Location(w,
                            p.minX() + rnd.nextDouble() * dx,
                            p.minY() + rnd.nextDouble() * dy,
                            p.minZ() + rnd.nextDouble() * dz);
                    w.spawnParticle(Particle.END_ROD, loc, 1, 0, 0, 0, 0.02);
                }
            }

            if (sound && tick % 80 == 0) {
                w.playSound(center, Sound.BLOCK_PORTAL_AMBIENT, 0.15f, 1.0f);
            }
        }
    }

    /** Эффект в момент входа игрока в портал. */
    void enter(Player p) {
        if (!enabled) return;
        Location loc = p.getLocation().add(0, 1, 0);
        World w = p.getWorld();
        w.spawnParticle(Particle.REVERSE_PORTAL, loc, 60, 0.4, 0.8, 0.4, 0.1);
        w.spawnParticle(Particle.END_ROD, loc, 20, 0.3, 0.6, 0.3, 0.08);
        if (sound) {
            p.playSound(p.getLocation(), Sound.BLOCK_PORTAL_TRAVEL, 0.3f, 1.4f);
        }
        if (!title.isEmpty() || !subtitle.isEmpty()) {
            var ser = LegacyComponentSerializer.legacyAmpersand();
            Component t = ser.deserialize(title);
            Component s = ser.deserialize(subtitle);
            p.showTitle(Title.title(t, s, Title.Times.times(
                    Duration.ofMillis(200), Duration.ofMillis(900), Duration.ofMillis(300))));
        }
    }

    private Location point(World w, boolean longX, double cx, double cz, double a, double y) {
        return longX ? new Location(w, a, y, cz) : new Location(w, cx, y, a);
    }

    private void dust(World w, Location loc, float size) {
        w.spawnParticle(Particle.DUST_COLOR_TRANSITION, loc, 1, 0, 0, 0, 0,
                new Particle.DustTransition(from, to, size));
    }
}
