package dev.rtpportal;

import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;

public final class PortalManager {
    private final RtpPortalPlugin plugin;
    private final File file;
    private final Map<String, Portal> portals = new LinkedHashMap<>();

    public PortalManager(RtpPortalPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "portals.yml");
    }

    public void load() {
        portals.clear();
        if (!file.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection sec = yml.getConfigurationSection("portals");
        if (sec == null) return;
        for (String key : sec.getKeys(false)) {
            ConfigurationSection p = sec.getConfigurationSection(key);
            if (p == null) continue;
            String world = p.getString("world");
            if (world == null) continue;
            portals.put(key.toLowerCase(), new Portal(key, world,
                    p.getInt("min.x"), p.getInt("min.y"), p.getInt("min.z"),
                    p.getInt("max.x"), p.getInt("max.y"), p.getInt("max.z")));
        }
    }

    public void save() {
        YamlConfiguration yml = new YamlConfiguration();
        for (Portal p : portals.values()) {
            String base = "portals." + p.name();
            yml.set(base + ".world", p.world());
            yml.set(base + ".min.x", p.minX());
            yml.set(base + ".min.y", p.minY());
            yml.set(base + ".min.z", p.minZ());
            yml.set(base + ".max.x", p.maxX());
            yml.set(base + ".max.y", p.maxY());
            yml.set(base + ".max.z", p.maxZ());
        }
        try {
            plugin.getDataFolder().mkdirs();
            yml.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Не удалось сохранить portals.yml: " + e.getMessage());
        }
    }

    public boolean exists(String name) {
        return portals.containsKey(name.toLowerCase());
    }

    public void add(Portal portal) {
        portals.put(portal.name().toLowerCase(), portal);
        save();
    }

    public boolean remove(String name) {
        boolean removed = portals.remove(name.toLowerCase()) != null;
        if (removed) save();
        return removed;
    }

    public Collection<Portal> all() {
        return portals.values();
    }

    public Portal find(Location l) {
        for (Portal p : portals.values()) {
            if (p.contains(l)) return p;
        }
        return null;
    }
}
