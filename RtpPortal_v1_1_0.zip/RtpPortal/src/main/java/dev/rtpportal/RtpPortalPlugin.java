package dev.rtpportal;

import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public final class RtpPortalPlugin extends JavaPlugin implements Listener, CommandExecutor, TabCompleter {
    private PortalManager portals;
    private PortalEffects effects;
    private final Map<UUID, Location> pos1 = new HashMap<>();
    private final Map<UUID, Location> pos2 = new HashMap<>();
    private final Map<UUID, Long> lastUse = new HashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        portals = new PortalManager(this);
        portals.load();
        effects = new PortalEffects(this);
        effects.reload();

        getServer().getPluginManager().registerEvents(this, this);
        var cmd = getCommand("rtpportal");
        if (cmd != null) {
            cmd.setExecutor(this);
            cmd.setTabCompleter(this);
        }

        Bukkit.getScheduler().runTaskTimer(this, () -> effects.run(portals.all()), 20L, 2L);
        getLogger().info("Загружено порталов: " + portals.all().size());
    }

    // ---------- Срабатывание портала ----------

    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        if (!e.hasChangedBlock()) return;
        Player p = e.getPlayer();
        Portal now = portals.find(e.getTo());
        if (now == null) return;
        Portal before = portals.find(e.getFrom());
        if (before != null && before.name().equalsIgnoreCase(now.name())) return;
        if (!p.hasPermission("rtpportal.use")) return;

        long cooldown = getConfig().getLong("cooldown-seconds", 5) * 1000L;
        long nowMs = System.currentTimeMillis();
        Long last = lastUse.get(p.getUniqueId());
        if (last != null && nowMs - last < cooldown) return;
        lastUse.put(p.getUniqueId(), nowMs);

        effects.enter(p);
        String command = getConfig().getString("command", "rtp");
        String msg = getConfig().getString("messages.teleporting", "");
        if (!msg.isEmpty()) send(p, msg);
        Bukkit.getScheduler().runTask(this, () -> {
            if (p.isOnline()) Bukkit.dispatchCommand(p, command);
        });
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        lastUse.remove(id);
        pos1.remove(id);
        pos2.remove(id);
    }

    // ---------- Команды ----------

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 0) {
            send(sender, "&e/" + label + " pos1|pos2|create <имя>|remove <имя>|list|reload");
            return true;
        }
        String sub = args[0].toLowerCase();
        switch (sub) {
            case "pos1", "pos2" -> {
                if (!(sender instanceof Player p)) {
                    send(sender, "Только для игроков.");
                    return true;
                }
                Location l = p.getLocation().getBlock().getLocation();
                (sub.equals("pos1") ? pos1 : pos2).put(p.getUniqueId(), l);
                send(sender, "Точка " + (sub.equals("pos1") ? "1" : "2") + ": &e"
                        + l.getBlockX() + " " + l.getBlockY() + " " + l.getBlockZ());
            }
            case "create" -> {
                if (!(sender instanceof Player p)) {
                    send(sender, "Только для игроков.");
                    return true;
                }
                if (args.length < 2) {
                    send(sender, "Укажите имя: &e/" + label + " create <имя>");
                    return true;
                }
                String name = args[1];
                Location a = pos1.get(p.getUniqueId());
                Location b = pos2.get(p.getUniqueId());
                if (a == null || b == null) {
                    send(sender, "Сначала задайте обе точки: &e/" + label + " pos1&7 и &e/" + label + " pos2");
                    return true;
                }
                if (a.getWorld() == null || !a.getWorld().equals(b.getWorld())) {
                    send(sender, "Точки должны быть в одном мире.");
                    return true;
                }
                boolean replaced = portals.exists(name);
                portals.add(new Portal(name, a.getWorld().getName(),
                        Math.min(a.getBlockX(), b.getBlockX()),
                        Math.min(a.getBlockY(), b.getBlockY()),
                        Math.min(a.getBlockZ(), b.getBlockZ()),
                        Math.max(a.getBlockX(), b.getBlockX()),
                        Math.max(a.getBlockY(), b.getBlockY()),
                        Math.max(a.getBlockZ(), b.getBlockZ())));
                send(sender, (replaced ? "Портал обновлён: &e" : "Портал создан: &e") + name);
            }
            case "remove" -> {
                if (args.length < 2) {
                    send(sender, "Укажите имя: &e/" + label + " remove <имя>");
                    return true;
                }
                if (portals.remove(args[1])) send(sender, "Портал удалён: &e" + args[1]);
                else send(sender, "Портал не найден: &e" + args[1]);
            }
            case "list" -> {
                if (portals.all().isEmpty()) {
                    send(sender, "Порталов нет.");
                    return true;
                }
                for (Portal p : portals.all()) {
                    send(sender, "&e" + p.name() + "&7 (" + p.world() + ") "
                            + p.minX() + " " + p.minY() + " " + p.minZ() + " → "
                            + p.maxX() + " " + p.maxY() + " " + p.maxZ());
                }
            }
            case "reload" -> {
                reloadConfig();
                portals.load();
                effects.reload();
                send(sender, "Перезагружено. Порталов: &e" + portals.all().size());
            }
            default -> send(sender, "Неизвестная подкоманда.");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            for (String s : List.of("pos1", "pos2", "create", "remove", "list", "reload")) {
                if (s.startsWith(args[0].toLowerCase())) out.add(s);
            }
        } else if (args.length == 2 && args[0].equalsIgnoreCase("remove")) {
            for (Portal p : portals.all()) {
                if (p.name().toLowerCase().startsWith(args[1].toLowerCase())) out.add(p.name());
            }
        }
        return out;
    }

    private void send(CommandSender to, String text) {
        String prefix = getConfig().getString("messages.prefix", "");
        to.sendMessage(LegacyComponentSerializer.legacyAmpersand().deserialize(prefix + text));
    }
}
